class RemovedInMarshmallow4Warning(DeprecationWarning):
    pass
